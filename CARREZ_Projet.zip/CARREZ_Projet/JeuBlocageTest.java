public class JeuBlocageTest
{
    static void afficherGrilleVide(Cellule affiche)
	{
		Ecran.afficherln("  +------------------------+");
		for ( int i = 1 ; i <= 10 ; i++)
		{
			// Evite le décalage de la dixième ligne avec le numéro 10
			if(i < 10)
			{
				Ecran.afficher(" " + i + "|");
			}
			else
			{
				Ecran.afficher(i + "|");
			}
			
			for (int j = 1; j <= 12; j++)
			{
				Ecran.afficher(". ");
			}
			Ecran.afficherln("|");
			Ecran.sautDeLigne();
		}
		Ecran.afficherln("  +------------------------+");
		Ecran.afficherln("   A B C D E F G H I J K L");
	}
		
    

	static class Cellule
	{
		private String cellVide; // Caractère symbolisant une cellule vide, une cellule Joueur ou une celluleIA
		
		/*Cellule(String cVi, String cJo, String cIA)
		{
			this.cellVide = cVi;
			this.cellJou = cJo;
			this.cellIA = cIA;
		}

		void setCellule(String cVi, String cJo, String cIA)
		{
			this.cellVide = cVi;
			this.cellJou = cJo;
			this.cellIA = cIA;
		}
		
		String getcellIA() {
			return cellIA;
		}
		String getcellJou() {
			return cellJou;
		}
		String getcellVide() {
			return cellVide;
		}*/
		
	}
	
	public static void main(String [] args)
	{
		Cellule afficheGrilleVide = new Cellule();
		afficherGrilleVide( afficheGrilleVide );
		/*Cellule typeCellule = new Cellule(".", "0", "&");
		Grille affichage = new Grille();

		String celluleJoueur = cellule.getcellJou();
		String celluleVide = cellule.getcellVide();
		String celluleIA = cellule.getcellIA();
		
		String affichageGrilleVide = afficherGrille();
		Ecran.afficher( affichageGrilleVide );*/
		
	}
}